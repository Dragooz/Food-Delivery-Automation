# %%
from datetime import datetime, timedelta
from mypackage.helpers import Helper
from mypackage.constants import COLOR_DICT, SORTER, KK_DICT, SHOP_NAME, ALL_SERIES
import io
from apiclient import errors

# %%
import os
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google.oauth2 import service_account
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload, MediaIoBaseDownload

from httplib2 import Http
import pandas as pd
from dotenv import load_dotenv

from mypackage.helpers import Helper
from mypackage.constants import SHOP_NAME

from openpyxl import load_workbook, Workbook
import logging

#create a logger
logging.basicConfig(level=logging.INFO)

def create_excel_input(service_form, service_sheet, formId):
    '''
    Retrieve google sheet and create csv locally
    '''
    # Retrieve google sheet
    form = service_form.forms().get(formId=formId).execute()
    sheet_res = service_sheet.spreadsheets().get(spreadsheetId=form['linkedSheetId']).execute()
    dataset = service_sheet.spreadsheets().values().get(
        spreadsheetId= sheet_res['spreadsheetId'],
        range=sheet_res['sheets'][0]['properties']['title'],
        majorDimension= 'ROWS',
    ).execute()
    df = pd.DataFrame(dataset['values'])
    df = df.rename(columns=df.iloc[0]).drop(df.index[0])
    df = pd.concat([df, df])
    columns_name = list(df.columns)
    column_d, column_e, column_f = columns_name[3], columns_name[4], columns_name[5]
    if df.duplicated(subset=[column_d, column_e, column_f], keep=False).any() == True:
        df_duplicated = df.loc[df.duplicated()]
        file_name_duplicated = f"{sheet_res['properties']['title'].replace('/', '-')}_duplicated.csv"
        df_duplicated.to_csv(file_name_duplicated, index=False)
        df.drop_duplicates(subset=[column_d, column_e, column_f], keep='first', inplace=True)
    else:
        file_name_duplicated="None"

    file_name_real = f"{sheet_res['properties']['title'].replace('/', '-')}_Generated.csv"
    df.to_csv(file_name_real, index=False)
    if file_name_duplicated != "None":
        return df, [file_name_real, file_name_duplicated]
    return df, [file_name_real]

def create_all_output(kimseng_helper_obj, hyk_helper_obj, today_str, df_input, is_kimseng):
    if is_kimseng:
        excel_output_path, image_output_path, txt_name_list = kimseng_helper_obj.run_ks(df_input, today_str)
        return excel_output_path, image_output_path, txt_name_list
    else:
        excel_output_path, image_output_path, txt_name_list = hyk_helper_obj.run_hyk(df_input, today_str)
        return excel_output_path, image_output_path, txt_name_list

def get_or_create_folder_id(service_drive, file_name, parents=None, is_root=False):
    '''
    file_name: File's Name
    parents: [File Id]
    '''
    file_id = ''
    if is_root:
      files = service_drive.files().list( q=f"name='{file_name}' and mimeType='application/vnd.google-apps.folder' and trashed=false and parents in '{parents[0]}' " ,
                                       spaces='drive').execute()['files']
    else:
      files = service_drive.files().list( q=f"name='{file_name}' and mimeType='application/vnd.google-apps.folder' and trashed=false" ,
                                       spaces='drive').execute()['files']
    if len(files) > 0: #exist
        print(f"{file_name} exist. ")
        file_id = files[0].get('id')
        return file_id
    #create folder
    file_metadata = {
            'name': f"{file_name}",
            'mimeType': 'application/vnd.google-apps.folder',
            'parents': parents, 
        }

    res_file = service_drive.files().create(body=file_metadata, supportsAllDrives=True, fields='id').execute()
    file_id = res_file.get('id')
    # service_drive.permissions().create(fileId = file_id, body={"role": "reader", "type":"user", "emailAddress": "byichonggoh@gmail.com"}, supportsAllDrives=True, fields='id').execute()
    return file_id

def file_exist(service_drive, file_name, mimetype):
    files = service_drive.files().list( q=f"name = '{file_name}' and mimeType = '{mimetype}' and trashed = false" ,
                                       spaces='drive',).execute()['files']
    if len(files) > 0: #exist
        return files[0].get('id')
    return False

def upload_input_file(service_drive, file_name, parents):
    '''
    Input:
    file_name: File's Name
    parents: [File Id]
    '''
    file_metadata = {'name': file_name,'parents': parents,}
    file_media = MediaFileUpload(file_name, mimetype='text/csv')
    if file_id := file_exist(service_drive, file_name, 'text/csv'):
        service_drive.files().update(fileId=file_id, body={'name': file_name}, media_body=file_media, fields='id').execute()['id']
    else:
        file_id = service_drive.files().create(body=file_metadata, media_body=file_media, fields='id').execute()['id']
    file_media = None #To stop reading the file to allow delete

def upload_output_file(service_drive, parents, excel_name="", image_name="", txt_name_list=[]):
    '''
    Output
    file_name: File's Name
    parents: [File Id]
    '''

    if image_name != "":
        image_metadata = {'name': image_name, 'parents': parents,}
        image_media = MediaFileUpload(image_name, mimetype='image/png')
        # if image_file_id := file_exist(image_name, 'image/png'):
        #     service_drive.files().update(fileId= image_file_id, body={'name': image_name}, media_body=image_media, fields='id').execute()['id']
        # else:
        image_file_id = service_drive.files().create(body=image_metadata, media_body=image_media, fields='id').execute()['id']
        image_media=None
    
    if txt_name_list != []:
        for txt_name in txt_name_list:
            text_metadata = {'name': txt_name,'parents': parents,}
            text_media = MediaFileUpload(txt_name, mimetype='text/plain')
            # if text_file_id := file_exist(txt_name, 'text/plain'):
            #     service_drive.files().update(fileId=text_file_id, body={'name': txt_name}, media_body=text_media, fields='id').execute()['id']
            # else:
            text_file_id = service_drive.files().create(body=text_metadata, media_body=text_media, fields='id').execute()['id']
            text_media=None

    if excel_name != "":
        excel_metadata = {'name': excel_name,'parents': parents}
        excel_media = MediaFileUpload(excel_name, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        # if excel_file_id := file_exist(excel_name, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'):
        #     service_drive.files().update(fileId=excel_file_id, body={'name': excel_name}, media_body=excel_media, fields='id').execute()['id']
        # else:
        excel_file_id = service_drive.files().create(body=excel_metadata, media_body=excel_media, fields='id').execute()['id']
        excel_media=None

def run_program(form_id, folder_input_id, folder_output_today_id, is_kimseng=False):
    df_input, excel_input_name_list = create_excel_input(form_id)
    logging.info(f"Created Excel Input file list!")
    if len(excel_input_name_list) > 1:
        #this is the duplicate file if exist
        logging.info(f"There's duplicated record. Creating a file for that...")
        upload_input_file(excel_input_name_list[1], [folder_output_today_id])
        logging.info(f"Uploaded excel input duplicated file to output folder!")
        os.remove(excel_input_name_list[1])
    upload_input_file(excel_input_name_list[0], [folder_input_id])
    logging.info(f"Uploaded excel input generated file to input folder!")
    os.remove(excel_input_name_list[0])
    
    excel_output_path, image_output_path, txt_name_list = create_all_output(df_input, is_kimseng)
    upload_output_file([folder_output_today_id], excel_name=excel_output_path, image_name=image_output_path, txt_name_list=txt_name_list)
    logging.info(f"Uploaded all the output files!")
    os.remove(excel_output_path)
    os.remove(image_output_path)
    [os.remove(txt_name) for txt_name in txt_name_list]
    return df_input

def run():
    #setup
    logging.info("Loading local environment...")
    load_dotenv()

    SERVICE_ACCOUNT = os.getenv('SERVICE_ACCOUNT') #The service acc used to create files.
    GOOGLE_SHEET_ID = os.getenv("GOOGLE_SHEET_ID") #the shared google sheet that user can access and input ID
    SHARED_PARENT_FOLDER_ID = os.getenv("SHARED_PARENT_FOLDER_ID") #the shared parent folder on personal acc

    SCOPES = ["https://www.googleapis.com/auth/forms.body", "https://www.googleapis.com/auth/drive", "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/forms.responses.readonly", "https://www.googleapis.com/auth/spreadsheets.readonly"]

    credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT, scopes=SCOPES)
    ks_hyk_helper_obj = Helper.KS_HYK()
    kimseng_helper_obj = Helper.KimSeng()
    hyk_helper_obj = Helper.HYK()

    logging.info("Building Google's Credentials...")
    today_str = (datetime.today() + timedelta(days=1)).strftime('%d-%m-%Y') #today_str = date that file should be run. Hence if today is 04/01/2023, then today str should be 05/01/2023 so that 05/01/2023 row will be read.
    service_form = build('forms', 'v1', credentials=credentials) #forms
    service_sheet = build('sheets', 'v4', credentials=credentials)
    service_drive = build('drive', 'v3', credentials=credentials)

    #create stuff
    #so the idea here is to export to files, upload the files, and delete the files. can be triggered through the form id
    logging.info("Creating/Getting all folder ids...")
    ks_j_hyk_folder_id = get_or_create_folder_id(service_drive, 'KS&J&HYK', [SHARED_PARENT_FOLDER_ID], is_root=True)
    kimseng_folder_id = get_or_create_folder_id(service_drive, 'KimSeng', [ks_j_hyk_folder_id])
    kimseng_folder_input_id = get_or_create_folder_id(service_drive, 'KimSengInput', [kimseng_folder_id])
    kimseng_folder_output_id = get_or_create_folder_id(service_drive, 'KimSengOutput', [kimseng_folder_id])
    kimseng_folder_output_today_id = get_or_create_folder_id(service_drive, f'{today_str} Koutput', [kimseng_folder_output_id])

    hyk_folder_id = get_or_create_folder_id(service_drive, 'HYK', [ks_j_hyk_folder_id])
    hyk_folder_input_id = get_or_create_folder_id(service_drive, 'HYKInput', [hyk_folder_id])
    hyk_folder_output_id = get_or_create_folder_id(service_drive, 'HYKOutput', [hyk_folder_id])
    hyk_folder_output_today_id = get_or_create_folder_id(service_drive, f'{today_str} HYKOutput', [hyk_folder_output_id])

    logging.info("Getting Google Sheet ID information...")
    #get sheet list
    sheet_res = service_sheet.spreadsheets().get(spreadsheetId=GOOGLE_SHEET_ID).execute()
    dataset = service_sheet.spreadsheets().values().get(
            spreadsheetId= sheet_res['spreadsheetId'],
            range=sheet_res['sheets'][0]['properties']['title'],
            majorDimension= 'ROWS',
        ).execute()
    google_sheet_df = pd.DataFrame(dataset['values'])
    google_sheet_df = google_sheet_df.rename(columns=google_sheet_df.iloc[0]).drop(google_sheet_df.index[0])
    google_sheet_df = google_sheet_df[google_sheet_df['Date'] == today_str]

    logging.info("Running Kim Seng program...")
    # Kimseng
    ks_df_input = hyk_df_input = pd.DataFrame()
    kimseng_form_id = google_sheet_df["KimSeng"].item()
    if kimseng_form_id != "None":
        ks_df_input = run_program(service_form, service_sheet, kimseng_helper_obj, hyk_helper_obj, today_str, service_drive, kimseng_form_id, kimseng_folder_input_id, kimseng_folder_output_today_id, is_kimseng=True)
    else:
        logging.info(f"Kim Seng Google Form ID is none!")

    logging.info("Running HYK Program...")
    #hyk
    hyk_form_id = google_sheet_df["HYK"].item()
    if hyk_form_id != "None":
        hyk_df_input = run_program(service_form, service_sheet, kimseng_helper_obj, hyk_helper_obj, today_str, service_drive, hyk_form_id, hyk_folder_input_id, hyk_folder_output_today_id, is_kimseng=False)
    else:
        logging.info(f"HYK Google Form ID is none!")

    if not ks_df_input.empty and not hyk_df_input.empty:
        #kshyk combined text
        logging.info("KS and HYK df are both not empty. Generating txt files...")
        kshyk_text_name_list=['KSHYK driver.txt', 'Parttimer Salary.txt']
        ks_hyk_helper_obj.output_text_kshyk(ks_df_input, hyk_df_input, kshyk_text_name_list)
        upload_output_file(service_drive, [kimseng_folder_output_today_id], txt_name_list=kshyk_text_name_list)
        upload_output_file(service_drive, [hyk_folder_output_today_id], txt_name_list=kshyk_text_name_list)
        [os.remove(txt_name) for txt_name in kshyk_text_name_list]

        #calculations
        FILE_NAME = 'Kimseng Calculator.xlsx'
        OUTPUT_FILE_NAME = f'{today_str} {FILE_NAME}'
        df_acc = pd.read_excel(FILE_NAME, sheet_name='Sheet1')
        hyk_quantities= df_acc.apply(lambda row: list(hyk_df_input['Set']).count(row['Code']) , axis=1)
        kimseng_quantity= ks_df_input['Email Address'].count()

        workbook_data_only = load_workbook(filename= FILE_NAME, data_only=False)
        ws_data = workbook_data_only.get_sheet_by_name('Sheet1') #initial data

        for index, quantity in enumerate(hyk_quantities):
            ws_data[f'B{index+2}'] = quantity

        ws_data[f'C2'] = kimseng_quantity
        workbook_data_only.save(OUTPUT_FILE_NAME)

        upload_output_file(service_drive, [kimseng_folder_output_today_id], excel_name=OUTPUT_FILE_NAME)
        upload_output_file(service_drive, [hyk_folder_output_today_id], excel_name=OUTPUT_FILE_NAME)
        os.remove(OUTPUT_FILE_NAME)

if __name__ == '__main__':
    run()

